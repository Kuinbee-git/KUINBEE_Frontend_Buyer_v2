"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MarketplaceQuestionDtoSchema = exports.MarketplaceAnswerDtoSchema = exports.MarketplaceReviewDtoSchema = exports.MarketplaceCategoryDtoSchema = exports.MarketplaceDatasetDetailsDtoSchema = exports.MarketplaceDatasetListItemDtoSchema = exports.MarketplaceLocationInfoDtoSchema = exports.MarketplaceSourceDtoSchema = exports.MarketplaceFeatureDtoSchema = exports.MarketplaceDataFormatInfoDtoSchema = exports.MarketplaceAboutDatasetInfoDtoSchema = exports.MarketplaceDataFormatInfoLiteDtoSchema = exports.MarketplaceLocationLiteDtoSchema = exports.MarketplaceCategoryLiteDtoSchema = exports.MarketplaceOwnerDtoSchema = exports.MarketplaceDatasetPriceSurfaceDtoSchema = exports.MarketplaceDatasetCommercialFlowSchema = exports.MarketplaceDatasetAccessFlowSchema = exports.MarketplaceDatasetDiscountDtoSchema = exports.MarketplaceDatasetStatusSchema = void 0;
const zod_1 = require("zod");
const cataloguePrimitives_schema_1 = require("./cataloguePrimitives.schema");
const cataloguePrimitives_schema_2 = require("./cataloguePrimitives.schema");
exports.MarketplaceDatasetStatusSchema = zod_1.z.literal("PUBLISHED");
exports.MarketplaceDatasetDiscountDtoSchema = zod_1.z.object({
    proposalId: cataloguePrimitives_schema_1.CuidSchema,
    type: cataloguePrimitives_schema_2.DatasetDiscountTypeSchema,
    value: cataloguePrimitives_schema_2.DecimalStringSchema,
    amountOff: cataloguePrimitives_schema_2.DecimalStringSchema,
    startsAt: cataloguePrimitives_schema_1.IsoDateTimeStringSchema,
    endsAt: cataloguePrimitives_schema_1.IsoDateTimeStringSchema,
});
exports.MarketplaceDatasetAccessFlowSchema = zod_1.z.enum([
    "FREE_CLAIM",
    "PAID_CHECKOUT",
]);
exports.MarketplaceDatasetCommercialFlowSchema = zod_1.z.enum([
    "NONE",
    "DIRECT_PLATFORM_PURCHASE",
    "INQUIRY_FOR_FULL_DATASET",
]);
exports.MarketplaceDatasetPriceSurfaceDtoSchema = zod_1.z.object({
    surface: cataloguePrimitives_schema_2.DatasetDiscountTargetSurfaceSchema.nullable(),
    baseAmount: cataloguePrimitives_schema_2.DecimalStringSchema.nullable(),
    finalAmount: cataloguePrimitives_schema_2.DecimalStringSchema.nullable(),
    currency: zod_1.z.string().min(1).nullable(),
    discount: exports.MarketplaceDatasetDiscountDtoSchema.nullable(),
    payable: zod_1.z.boolean(),
    visible: zod_1.z.boolean(),
});
exports.MarketplaceOwnerDtoSchema = zod_1.z.object({
    id: cataloguePrimitives_schema_1.CuidSchema,
    type: zod_1.z.enum(["platform", "supplier"]),
    name: zod_1.z.string().min(1),
    logoUrl: zod_1.z.string().min(1).nullable().optional(),
});
exports.MarketplaceCategoryLiteDtoSchema = zod_1.z.object({
    name: zod_1.z.string().min(1),
});
exports.MarketplaceLocationLiteDtoSchema = zod_1.z.object({
    country: zod_1.z.string().min(1),
    state: zod_1.z.string().min(1).nullable(),
    city: zod_1.z.string().min(1).nullable(),
});
exports.MarketplaceDataFormatInfoLiteDtoSchema = zod_1.z.object({
    fileFormat: zod_1.z.string().min(1).nullable(),
    rows: zod_1.z.number().int().min(0).nullable(),
    cols: zod_1.z.number().int().min(0).nullable(),
    fileSize: cataloguePrimitives_schema_2.BigIntStringSchema.nullable(),
});
exports.MarketplaceAboutDatasetInfoDtoSchema = zod_1.z.object({
    overview: zod_1.z.string().min(1).nullable(),
    description: zod_1.z.string().min(1).nullable(),
    dataQuality: zod_1.z.string().min(1).nullable(),
    useCases: zod_1.z.string().min(1).nullable(),
    limitations: zod_1.z.string().min(1).nullable(),
    methodology: zod_1.z.string().min(1).nullable(),
    updatedAt: cataloguePrimitives_schema_1.IsoDateTimeStringSchema.nullable(),
});
exports.MarketplaceDataFormatInfoDtoSchema = zod_1.z.object({
    fileFormat: zod_1.z.string().min(1).nullable(),
    rows: zod_1.z.number().int().min(0).nullable(),
    cols: zod_1.z.number().int().min(0).nullable(),
    fileSize: cataloguePrimitives_schema_2.BigIntStringSchema.nullable(),
    compressionType: zod_1.z.string().min(1).nullable(),
    encoding: cataloguePrimitives_schema_2.EncodingSchema.nullable(),
    updatedAt: cataloguePrimitives_schema_1.IsoDateTimeStringSchema.nullable(),
});
exports.MarketplaceFeatureDtoSchema = zod_1.z.object({
    id: cataloguePrimitives_schema_1.CuidSchema,
    name: zod_1.z.string().min(1),
    dataType: zod_1.z.string().min(1),
    description: zod_1.z.string().min(1).nullable(),
    isNullable: zod_1.z.boolean(),
});
exports.MarketplaceSourceDtoSchema = zod_1.z.object({
    id: cataloguePrimitives_schema_1.CuidSchema,
    name: zod_1.z.string().min(1),
    description: zod_1.z.string().min(1).nullable(),
    websiteUrl: zod_1.z.string().min(1).nullable(),
    isVerified: zod_1.z.boolean(),
});
exports.MarketplaceLocationInfoDtoSchema = zod_1.z.object({
    region: zod_1.z.string().min(1).nullable(),
    country: zod_1.z.string().min(1),
    state: zod_1.z.string().min(1).nullable(),
    city: zod_1.z.string().min(1).nullable(),
    coordinates: zod_1.z.string().min(1).nullable(),
    coverage: zod_1.z.string().min(1).nullable(),
});
exports.MarketplaceDatasetListItemDtoSchema = zod_1.z.object({
    id: cataloguePrimitives_schema_1.CuidSchema,
    datasetUniqueId: zod_1.z.string().min(1),
    title: zod_1.z.string().min(1),
    status: exports.MarketplaceDatasetStatusSchema,
    license: zod_1.z.string().min(1),
    owner: exports.MarketplaceOwnerDtoSchema,
    category: exports.MarketplaceCategoryLiteDtoSchema,
    secondaryCategories: zod_1.z.array(exports.MarketplaceCategoryLiteDtoSchema).optional(),
    location: exports.MarketplaceLocationLiteDtoSchema.nullable(),
    dataFormatInfo: exports.MarketplaceDataFormatInfoLiteDtoSchema,
    tags: zod_1.z.array(zod_1.z.string().min(1)),
    isPaid: zod_1.z.boolean(),
    price: cataloguePrimitives_schema_2.DecimalStringSchema.nullable(),
    currency: cataloguePrimitives_schema_2.CurrencySchema,
    accessFlow: exports.MarketplaceDatasetAccessFlowSchema,
    commercialFlow: exports.MarketplaceDatasetCommercialFlowSchema,
    accessPrice: exports.MarketplaceDatasetPriceSurfaceDtoSchema,
    commercialPrice: exports.MarketplaceDatasetPriceSurfaceDtoSchema,
    viewCount: zod_1.z.number().int().min(0),
    downloadCount: zod_1.z.number().int().min(0),
    reviewCount: zod_1.z.number().int().min(0),
    rating: cataloguePrimitives_schema_2.DecimalStringSchema.nullable(),
    kdtsScore: cataloguePrimitives_schema_2.DecimalStringSchema.nullable(),
    searchScore: zod_1.z.number().nullable().optional(),
    isSample: zod_1.z.boolean(),
    sampleFileAvailable: zod_1.z.boolean(),
    sampleNotes: zod_1.z
        .object({
        whySample: zod_1.z.string().min(1),
        actualDataSize: zod_1.z.string().min(1),
        completeness: zod_1.z.string().min(1).optional(),
        deliveryMechanism: zod_1.z.enum(["API", "FILE", "OTHER"]),
        deliveryMechanismNotes: zod_1.z.string().min(1).optional(),
    })
        .nullable()
        .optional(),
    actualPrice: cataloguePrimitives_schema_2.DecimalStringSchema.nullable(),
    actualPriceCurrency: zod_1.z.string().min(1).nullable(),
    buyInPartsAvailable: zod_1.z.boolean(),
    createdAt: cataloguePrimitives_schema_1.IsoDateTimeStringSchema,
    updatedAt: cataloguePrimitives_schema_1.IsoDateTimeStringSchema,
});
exports.MarketplaceDatasetDetailsDtoSchema = zod_1.z.object({
    dataset: zod_1.z.object({
        id: cataloguePrimitives_schema_1.CuidSchema,
        datasetUniqueId: zod_1.z.string().min(1),
        title: zod_1.z.string().min(1),
        status: exports.MarketplaceDatasetStatusSchema,
        visibility: cataloguePrimitives_schema_2.DatasetVisibilitySchema,
        superType: zod_1.z.string().min(1),
        isPaid: zod_1.z.boolean(),
        price: cataloguePrimitives_schema_2.DecimalStringSchema.nullable(),
        currency: cataloguePrimitives_schema_2.CurrencySchema,
        accessFlow: exports.MarketplaceDatasetAccessFlowSchema,
        commercialFlow: exports.MarketplaceDatasetCommercialFlowSchema,
        accessPrice: exports.MarketplaceDatasetPriceSurfaceDtoSchema,
        commercialPrice: exports.MarketplaceDatasetPriceSurfaceDtoSchema,
        license: zod_1.z.string().min(1),
        downloadCount: zod_1.z.number().int().min(0),
        viewCount: zod_1.z.number().int().min(0),
        rating: cataloguePrimitives_schema_2.DecimalStringSchema.nullable(),
        createdAt: cataloguePrimitives_schema_1.IsoDateTimeStringSchema,
        updatedAt: cataloguePrimitives_schema_1.IsoDateTimeStringSchema,
        description: zod_1.z.string().min(1).nullable(),
        isSample: zod_1.z.boolean(),
        sampleFileAvailable: zod_1.z.boolean(),
        sampleNotes: zod_1.z
            .object({
            whySample: zod_1.z.string().min(1),
            actualDataSize: zod_1.z.string().min(1),
            completeness: zod_1.z.string().min(1).optional(),
            deliveryMechanism: zod_1.z.enum(["API", "FILE", "OTHER"]),
            deliveryMechanismNotes: zod_1.z.string().min(1).optional(),
        })
            .nullable(),
        actualPrice: cataloguePrimitives_schema_2.DecimalStringSchema.nullable(),
        actualPriceCurrency: zod_1.z.string().min(1).nullable(),
        isNegotiable: zod_1.z.boolean().nullable(),
        buyInPartsAvailable: zod_1.z.boolean(),
    }),
    primaryCategory: exports.MarketplaceCategoryLiteDtoSchema,
    secondaryCategories: zod_1.z.array(exports.MarketplaceCategoryLiteDtoSchema),
    aboutDatasetInfo: exports.MarketplaceAboutDatasetInfoDtoSchema,
    dataFormatInfo: exports.MarketplaceDataFormatInfoDtoSchema,
    features: zod_1.z.array(exports.MarketplaceFeatureDtoSchema),
    source: exports.MarketplaceSourceDtoSchema,
    locationInfo: exports.MarketplaceLocationInfoDtoSchema.nullable(),
    tags: zod_1.z.array(zod_1.z.string().min(1)),
});
exports.MarketplaceCategoryDtoSchema = zod_1.z.object({
    id: cataloguePrimitives_schema_1.CuidSchema,
    name: zod_1.z.string().min(1),
    datasetCount: zod_1.z.number().int().min(0),
});
exports.MarketplaceReviewDtoSchema = zod_1.z.object({
    id: cataloguePrimitives_schema_1.CuidSchema,
    rating: zod_1.z.number().int().min(1).max(5),
    comment: zod_1.z.string().min(1).nullable(),
    createdAt: cataloguePrimitives_schema_1.IsoDateTimeStringSchema,
    updatedAt: cataloguePrimitives_schema_1.IsoDateTimeStringSchema.optional(),
});
exports.MarketplaceAnswerDtoSchema = zod_1.z.object({
    id: cataloguePrimitives_schema_1.CuidSchema,
    answer: zod_1.z.string().min(1),
    createdAt: cataloguePrimitives_schema_1.IsoDateTimeStringSchema,
});
exports.MarketplaceQuestionDtoSchema = zod_1.z.object({
    id: cataloguePrimitives_schema_1.CuidSchema,
    question: zod_1.z.string().min(1),
    answers: zod_1.z.array(exports.MarketplaceAnswerDtoSchema).default([]),
    createdAt: cataloguePrimitives_schema_1.IsoDateTimeStringSchema,
});
