"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatasetContentVisibilityBodySchema = exports.DatasetContentLifecycleBodySchema = exports.DatasetContentPublishBodySchema = exports.DatasetPublicationReadinessResponseSchema = exports.DatasetPublishedReviewResponseSchema = exports.DatasetPublicationResponseSchema = exports.DatasetContentAssessmentResponseSchema = exports.DatasetPublicationSchema = exports.DatasetContentAssessmentSchema = exports.DatasetContentAssessmentBodySchema = exports.DatasetContentAssessmentQuerySchema = exports.DatasetContentAssessmentTargetSchema = void 0;
const zod_1 = require("zod");
const workflow_schema_1 = require("./workflow.schema");
const id = zod_1.z.string().cuid();
const revision = zod_1.z.number().int().min(0).max(2_147_483_647);
const requestId = zod_1.z.string().uuid().transform(value => value.toLowerCase());
const score = zod_1.z.number().int().min(0).max(100);
exports.DatasetContentAssessmentTargetSchema = zod_1.z.enum(["REVIEWED", "PUBLISHED"]);
exports.DatasetContentAssessmentQuerySchema = zod_1.z.object({ target: exports.DatasetContentAssessmentTargetSchema.default("REVIEWED") }).strict();
exports.DatasetContentAssessmentBodySchema = zod_1.z.object({ requestId, expectedWorkflowRevision: revision, expectedContentId: id,
    target: exports.DatasetContentAssessmentTargetSchema.default("REVIEWED"), Q: score, L: score, P: score, U: score, F: score,
    note: zod_1.z.string().trim().min(1).max(4_000).optional() }).strict();
exports.DatasetContentAssessmentSchema = zod_1.z.object({ id, datasetId: id, contentId: id,
    Q: score, L: score, P: score, U: score, F: score, finalScore: zod_1.z.string().regex(/^(100|[0-9]{1,2})(\.[0-9]{2})$/),
    adminId: id, createdAt: zod_1.z.string().datetime(), note: zod_1.z.string().max(4_000).nullable(),
    scope: zod_1.z.object({ uploadedComponents: zod_1.z.array(zod_1.z.enum(["FULL", "SAMPLE"])).min(1).max(2),
        representedCollection: zod_1.z.literal("SUPPLIER_DECLARATION") }).strict(),
}).strict();
exports.DatasetPublicationSchema = zod_1.z.object({ id, contentId: id, publishedAt: zod_1.z.string().datetime(),
    pricingReference: workflow_schema_1.DatasetPricingReferenceSchema, pricingAtPublication: workflow_schema_1.DatasetPricingValuesSchema,
    assessmentAtPublicationId: id, currentAssessmentId: id.nullable(),
}).strict();
const state = workflow_schema_1.DatasetWorkflowStateSchema.omit({ pricing: true }).extend({ pricing: workflow_schema_1.DatasetWorkflowPricingSchema.pick({
        id: true, revision: true, status: true, isPaid: true, price: true, currency: true,
    }).nullable() });
exports.DatasetContentAssessmentResponseSchema = zod_1.z.object({ state,
    target: exports.DatasetContentAssessmentTargetSchema, assessment: exports.DatasetContentAssessmentSchema.nullable(),
}).strict().refine(value => !value.assessment ||
    (value.assessment.datasetId === value.state.datasetId && value.assessment.contentId ===
        (value.target === "REVIEWED" ? value.state.reviewedContentId : value.state.publishedContentId)), "Assessment belongs to the exact selected Dataset content");
exports.DatasetPublicationResponseSchema = zod_1.z.object({ requestId: requestId.optional(), state,
    visibility: zod_1.z.enum(["PUBLIC", "PRIVATE", "UNLISTED"]),
    publication: exports.DatasetPublicationSchema.nullable(), reviewedAssessment: exports.DatasetContentAssessmentSchema.omit({ note: true }).nullable(),
    publishedAssessment: exports.DatasetContentAssessmentSchema.omit({ note: true }).nullable(),
    assessmentChange: zod_1.z.object({ target: exports.DatasetContentAssessmentTargetSchema, assessment: exports.DatasetContentAssessmentSchema }).strict().optional(),
}).strict();
// A private exact published view is independent of the newer reviewed submission.
// Existing publication/submission responses retain their original contract.
exports.DatasetPublishedReviewResponseSchema = exports.DatasetPublicationResponseSchema.pick({ state: true, visibility: true, publication: true }).extend({
    publishedContent: workflow_schema_1.DatasetReviewResponseSchema.shape.submittedContent.nullable(),
}).strict().refine(value => value.state.publishedContentId === (value.publishedContent?.id ?? null) &&
    (value.publication?.contentId ?? null) === (value.publishedContent?.id ?? null), "Published metadata and publication must identify the exact current published content");
exports.DatasetPublicationReadinessResponseSchema = exports.DatasetPublicationResponseSchema.extend({
    contentId: id.nullable(), contentGeneration: revision.nullable(), dependencyFingerprint: zod_1.z.string().regex(/^[a-f0-9]{64}$/).nullable(),
    canPublish: zod_1.z.boolean(), issues: zod_1.z.array(zod_1.z.object({ code: zod_1.z.string().min(1).max(100), message: zod_1.z.string().min(1).max(1_000) }).strict()).max(100),
});
exports.DatasetContentPublishBodySchema = zod_1.z.object({ requestId, expectedWorkflowRevision: revision,
    expectedContentId: id, expectedContentGeneration: revision, expectedPricingReference: workflow_schema_1.DatasetPricingReferenceSchema,
    expectedAssessmentId: id, expectedDependencyFingerprint: zod_1.z.string().regex(/^[a-f0-9]{64}$/) }).strict();
exports.DatasetContentLifecycleBodySchema = zod_1.z.object({ requestId, expectedWorkflowRevision: revision,
    expectedPublishedContentId: id.nullable(), expectedPublicationId: id.nullable() }).strict();
exports.DatasetContentVisibilityBodySchema = exports.DatasetContentLifecycleBodySchema.extend({ visibility: zod_1.z.enum(["PUBLIC", "PRIVATE", "UNLISTED"]) });
