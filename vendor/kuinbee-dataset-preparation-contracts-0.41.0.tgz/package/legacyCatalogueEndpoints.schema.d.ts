import { z } from "zod";
export declare const MarketplaceDatasetsListSortSchema: z.ZodEnum<{
    "createdAt:desc": "createdAt:desc";
    "createdAt:asc": "createdAt:asc";
    "updatedAt:desc": "updatedAt:desc";
    "rating:desc": "rating:desc";
    relevance: "relevance";
    "price:asc": "price:asc";
    "price:desc": "price:desc";
    "viewCount:desc": "viewCount:desc";
    "downloadCount:desc": "downloadCount:desc";
    "kdtsScore:desc": "kdtsScore:desc";
}>;
export type MarketplaceDatasetsListSort = z.infer<typeof MarketplaceDatasetsListSortSchema>;
export declare const MarketplaceDatasetsListQuerySchema: z.ZodObject<{
    page: z.ZodOptional<z.ZodDefault<z.ZodCoercedNumber<unknown>>>;
    pageSize: z.ZodOptional<z.ZodDefault<z.ZodCoercedNumber<unknown>>>;
    q: z.ZodOptional<z.ZodString>;
    search: z.ZodOptional<z.ZodString>;
    categoryId: z.ZodOptional<z.ZodString>;
    categoryIds: z.ZodOptional<z.ZodPreprocess<z.ZodArray<z.ZodString>, unknown>>;
    isPaid: z.ZodOptional<z.ZodPreprocess<z.ZodBoolean, unknown>>;
    minPrice: z.ZodOptional<z.ZodString>;
    maxPrice: z.ZodOptional<z.ZodString>;
    currency: z.ZodOptional<z.ZodEnum<{
        INR: "INR";
        USD: "USD";
        EUR: "EUR";
        GBP: "GBP";
    }>>;
    country: z.ZodOptional<z.ZodString>;
    state: z.ZodOptional<z.ZodString>;
    city: z.ZodOptional<z.ZodString>;
    tags: z.ZodOptional<z.ZodPreprocess<z.ZodArray<z.ZodString>, unknown>>;
    minKdtsScore: z.ZodOptional<z.ZodString>;
    sort: z.ZodOptional<z.ZodEnum<{
        "createdAt:desc": "createdAt:desc";
        "createdAt:asc": "createdAt:asc";
        "updatedAt:desc": "updatedAt:desc";
        "rating:desc": "rating:desc";
        relevance: "relevance";
        "price:asc": "price:asc";
        "price:desc": "price:desc";
        "viewCount:desc": "viewCount:desc";
        "downloadCount:desc": "downloadCount:desc";
        "kdtsScore:desc": "kdtsScore:desc";
    }>>;
}, z.core.$strip>;
export type MarketplaceDatasetsListQuery = z.infer<typeof MarketplaceDatasetsListQuerySchema>;
export declare const MarketplaceDatasetsListResponseSchema: z.ZodObject<{
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        datasetUniqueId: z.ZodString;
        title: z.ZodString;
        status: z.ZodLiteral<"PUBLISHED">;
        license: z.ZodString;
        owner: z.ZodObject<{
            id: z.ZodString;
            type: z.ZodEnum<{
                supplier: "supplier";
                platform: "platform";
            }>;
            name: z.ZodString;
            logoUrl: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strip>;
        category: z.ZodObject<{
            name: z.ZodString;
        }, z.core.$strip>;
        location: z.ZodNullable<z.ZodObject<{
            country: z.ZodString;
            state: z.ZodNullable<z.ZodString>;
            city: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>>;
        dataFormatInfo: z.ZodObject<{
            fileFormat: z.ZodNullable<z.ZodString>;
            rows: z.ZodNullable<z.ZodNumber>;
            cols: z.ZodNullable<z.ZodNumber>;
            fileSize: z.ZodNullable<z.ZodString>;
        }, z.core.$strip>;
        tags: z.ZodArray<z.ZodString>;
        isPaid: z.ZodBoolean;
        price: z.ZodNullable<z.ZodString>;
        currency: z.ZodEnum<{
            INR: "INR";
            USD: "USD";
            EUR: "EUR";
            GBP: "GBP";
        }>;
        accessFlow: z.ZodEnum<{
            FREE_CLAIM: "FREE_CLAIM";
            PAID_CHECKOUT: "PAID_CHECKOUT";
        }>;
        commercialFlow: z.ZodEnum<{
            NONE: "NONE";
            DIRECT_PLATFORM_PURCHASE: "DIRECT_PLATFORM_PURCHASE";
            INQUIRY_FOR_FULL_DATASET: "INQUIRY_FOR_FULL_DATASET";
        }>;
        accessPrice: z.ZodObject<{
            surface: z.ZodNullable<z.ZodEnum<{
                DATASET_PRICING: "DATASET_PRICING";
                SAMPLE_ACTUAL_PRICE: "SAMPLE_ACTUAL_PRICE";
            }>>;
            baseAmount: z.ZodNullable<z.ZodString>;
            finalAmount: z.ZodNullable<z.ZodString>;
            currency: z.ZodNullable<z.ZodString>;
            discount: z.ZodNullable<z.ZodObject<{
                proposalId: z.ZodString;
                type: z.ZodEnum<{
                    PERCENTAGE: "PERCENTAGE";
                    FIXED_AMOUNT: "FIXED_AMOUNT";
                }>;
                value: z.ZodString;
                amountOff: z.ZodString;
                startsAt: z.ZodString;
                endsAt: z.ZodString;
            }, z.core.$strip>>;
            payable: z.ZodBoolean;
            visible: z.ZodBoolean;
        }, z.core.$strip>;
        commercialPrice: z.ZodObject<{
            surface: z.ZodNullable<z.ZodEnum<{
                DATASET_PRICING: "DATASET_PRICING";
                SAMPLE_ACTUAL_PRICE: "SAMPLE_ACTUAL_PRICE";
            }>>;
            baseAmount: z.ZodNullable<z.ZodString>;
            finalAmount: z.ZodNullable<z.ZodString>;
            currency: z.ZodNullable<z.ZodString>;
            discount: z.ZodNullable<z.ZodObject<{
                proposalId: z.ZodString;
                type: z.ZodEnum<{
                    PERCENTAGE: "PERCENTAGE";
                    FIXED_AMOUNT: "FIXED_AMOUNT";
                }>;
                value: z.ZodString;
                amountOff: z.ZodString;
                startsAt: z.ZodString;
                endsAt: z.ZodString;
            }, z.core.$strip>>;
            payable: z.ZodBoolean;
            visible: z.ZodBoolean;
        }, z.core.$strip>;
        viewCount: z.ZodNumber;
        downloadCount: z.ZodNumber;
        reviewCount: z.ZodNumber;
        rating: z.ZodNullable<z.ZodString>;
        kdtsScore: z.ZodNullable<z.ZodString>;
        searchScore: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
        isSample: z.ZodBoolean;
        sampleFileAvailable: z.ZodBoolean;
        sampleNotes: z.ZodOptional<z.ZodNullable<z.ZodObject<{
            whySample: z.ZodString;
            actualDataSize: z.ZodString;
            completeness: z.ZodOptional<z.ZodString>;
            deliveryMechanism: z.ZodEnum<{
                OTHER: "OTHER";
                API: "API";
                FILE: "FILE";
            }>;
            deliveryMechanismNotes: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>>;
        actualPrice: z.ZodNullable<z.ZodString>;
        actualPriceCurrency: z.ZodNullable<z.ZodString>;
        buyInPartsAvailable: z.ZodBoolean;
        createdAt: z.ZodString;
        updatedAt: z.ZodString;
    }, z.core.$strip>>;
    page: z.ZodNumber;
    pageSize: z.ZodNumber;
    total: z.ZodNumber;
}, z.core.$strip>;
export type MarketplaceDatasetsListResponse = z.infer<typeof MarketplaceDatasetsListResponseSchema>;
export declare const MarketplaceDatasetIdParamsSchema: z.ZodObject<{
    datasetId: z.ZodString;
}, z.core.$strip>;
export type MarketplaceDatasetIdParams = z.infer<typeof MarketplaceDatasetIdParamsSchema>;
export declare const MarketplaceDatasetGetResponseSchema: z.ZodObject<{
    dataset: z.ZodObject<{
        id: z.ZodString;
        datasetUniqueId: z.ZodString;
        title: z.ZodString;
        status: z.ZodLiteral<"PUBLISHED">;
        visibility: z.ZodEnum<{
            PUBLIC: "PUBLIC";
            PRIVATE: "PRIVATE";
            UNLISTED: "UNLISTED";
        }>;
        superType: z.ZodString;
        isPaid: z.ZodBoolean;
        price: z.ZodNullable<z.ZodString>;
        currency: z.ZodEnum<{
            INR: "INR";
            USD: "USD";
            EUR: "EUR";
            GBP: "GBP";
        }>;
        accessFlow: z.ZodEnum<{
            FREE_CLAIM: "FREE_CLAIM";
            PAID_CHECKOUT: "PAID_CHECKOUT";
        }>;
        commercialFlow: z.ZodEnum<{
            NONE: "NONE";
            DIRECT_PLATFORM_PURCHASE: "DIRECT_PLATFORM_PURCHASE";
            INQUIRY_FOR_FULL_DATASET: "INQUIRY_FOR_FULL_DATASET";
        }>;
        accessPrice: z.ZodObject<{
            surface: z.ZodNullable<z.ZodEnum<{
                DATASET_PRICING: "DATASET_PRICING";
                SAMPLE_ACTUAL_PRICE: "SAMPLE_ACTUAL_PRICE";
            }>>;
            baseAmount: z.ZodNullable<z.ZodString>;
            finalAmount: z.ZodNullable<z.ZodString>;
            currency: z.ZodNullable<z.ZodString>;
            discount: z.ZodNullable<z.ZodObject<{
                proposalId: z.ZodString;
                type: z.ZodEnum<{
                    PERCENTAGE: "PERCENTAGE";
                    FIXED_AMOUNT: "FIXED_AMOUNT";
                }>;
                value: z.ZodString;
                amountOff: z.ZodString;
                startsAt: z.ZodString;
                endsAt: z.ZodString;
            }, z.core.$strip>>;
            payable: z.ZodBoolean;
            visible: z.ZodBoolean;
        }, z.core.$strip>;
        commercialPrice: z.ZodObject<{
            surface: z.ZodNullable<z.ZodEnum<{
                DATASET_PRICING: "DATASET_PRICING";
                SAMPLE_ACTUAL_PRICE: "SAMPLE_ACTUAL_PRICE";
            }>>;
            baseAmount: z.ZodNullable<z.ZodString>;
            finalAmount: z.ZodNullable<z.ZodString>;
            currency: z.ZodNullable<z.ZodString>;
            discount: z.ZodNullable<z.ZodObject<{
                proposalId: z.ZodString;
                type: z.ZodEnum<{
                    PERCENTAGE: "PERCENTAGE";
                    FIXED_AMOUNT: "FIXED_AMOUNT";
                }>;
                value: z.ZodString;
                amountOff: z.ZodString;
                startsAt: z.ZodString;
                endsAt: z.ZodString;
            }, z.core.$strip>>;
            payable: z.ZodBoolean;
            visible: z.ZodBoolean;
        }, z.core.$strip>;
        license: z.ZodString;
        downloadCount: z.ZodNumber;
        viewCount: z.ZodNumber;
        rating: z.ZodNullable<z.ZodString>;
        createdAt: z.ZodString;
        updatedAt: z.ZodString;
        description: z.ZodNullable<z.ZodString>;
        isSample: z.ZodBoolean;
        sampleFileAvailable: z.ZodBoolean;
        sampleNotes: z.ZodNullable<z.ZodObject<{
            whySample: z.ZodString;
            actualDataSize: z.ZodString;
            completeness: z.ZodOptional<z.ZodString>;
            deliveryMechanism: z.ZodEnum<{
                OTHER: "OTHER";
                API: "API";
                FILE: "FILE";
            }>;
            deliveryMechanismNotes: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        actualPrice: z.ZodNullable<z.ZodString>;
        actualPriceCurrency: z.ZodNullable<z.ZodString>;
        isNegotiable: z.ZodNullable<z.ZodBoolean>;
        buyInPartsAvailable: z.ZodBoolean;
    }, z.core.$strip>;
    primaryCategory: z.ZodObject<{
        name: z.ZodString;
    }, z.core.$strip>;
    secondaryCategories: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
    }, z.core.$strip>>;
    aboutDatasetInfo: z.ZodObject<{
        overview: z.ZodNullable<z.ZodString>;
        description: z.ZodNullable<z.ZodString>;
        dataQuality: z.ZodNullable<z.ZodString>;
        useCases: z.ZodNullable<z.ZodString>;
        limitations: z.ZodNullable<z.ZodString>;
        methodology: z.ZodNullable<z.ZodString>;
        updatedAt: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>;
    dataFormatInfo: z.ZodObject<{
        fileFormat: z.ZodNullable<z.ZodString>;
        rows: z.ZodNullable<z.ZodNumber>;
        cols: z.ZodNullable<z.ZodNumber>;
        fileSize: z.ZodNullable<z.ZodString>;
        compressionType: z.ZodNullable<z.ZodString>;
        encoding: z.ZodNullable<z.ZodEnum<{
            "UTF-8": "UTF-8";
            "UTF-16": "UTF-16";
            "UTF-16LE": "UTF-16LE";
            "UTF-16BE": "UTF-16BE";
            "UTF-32": "UTF-32";
            ASCII: "ASCII";
            "ISO-8859-1": "ISO-8859-1";
            "WINDOWS-1252": "WINDOWS-1252";
            SHIFT_JIS: "SHIFT_JIS";
            GB18030: "GB18030";
        }>>;
        updatedAt: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>;
    features: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
        dataType: z.ZodString;
        description: z.ZodNullable<z.ZodString>;
        isNullable: z.ZodBoolean;
    }, z.core.$strip>>;
    source: z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
        description: z.ZodNullable<z.ZodString>;
        websiteUrl: z.ZodNullable<z.ZodString>;
        isVerified: z.ZodBoolean;
    }, z.core.$strip>;
    locationInfo: z.ZodNullable<z.ZodObject<{
        region: z.ZodNullable<z.ZodString>;
        country: z.ZodString;
        state: z.ZodNullable<z.ZodString>;
        city: z.ZodNullable<z.ZodString>;
        coordinates: z.ZodNullable<z.ZodString>;
        coverage: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>>;
    tags: z.ZodArray<z.ZodString>;
}, z.core.$strip>;
export type MarketplaceDatasetGetResponse = z.infer<typeof MarketplaceDatasetGetResponseSchema>;
export declare const MarketplaceDatasetSampleDownloadUrlResponseSchema: z.ZodObject<{
    url: z.ZodString;
    expiresAt: z.ZodString;
    upload: z.ZodObject<{
        id: z.ZodString;
        originalFileName: z.ZodNullable<z.ZodString>;
        contentType: z.ZodNullable<z.ZodString>;
        sizeBytes: z.ZodNullable<z.ZodString>;
    }, z.core.$strip>;
}, z.core.$strip>;
export type MarketplaceDatasetSampleDownloadUrlResponse = z.infer<typeof MarketplaceDatasetSampleDownloadUrlResponseSchema>;
//# sourceMappingURL=legacyCatalogueEndpoints.schema.d.ts.map