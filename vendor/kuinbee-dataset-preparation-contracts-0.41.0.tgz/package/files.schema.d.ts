import { z } from "zod";
export declare const DATASET_FILES_CONTRACT_VERSION: 1;
export declare const DATASET_FILES_PAGE_MAX = 50;
export declare const DatasetFilesMutationBodySchema: z.ZodObject<{
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    expectedContentId: z.ZodString;
    expectedGeneration: z.ZodNumber;
    editContext: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        mode: z.ZodLiteral<"EXISTING_DRAFT">;
        expectedContentId: z.ZodString;
        expectedGeneration: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        mode: z.ZodLiteral<"INITIALIZE">;
        expectedWorkflowRevision: z.ZodNumber;
        context: z.ZodEnum<{
            REQUESTED_CHANGES: "REQUESTED_CHANGES";
            MANAGED_EDIT: "MANAGED_EDIT";
            APPROVED_REEDIT: "APPROVED_REEDIT";
            PLATFORM_WITHDRAWAL: "PLATFORM_WITHDRAWAL";
            PLATFORM_PUBLISHED_METADATA: "PLATFORM_PUBLISHED_METADATA";
        }>;
        expectedBaseContentId: z.ZodString;
    }, z.core.$strict>], "mode">>;
    operations: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        operation: z.ZodLiteral<"ADD_MEMBER">;
        uploadObjectId: z.ZodString;
        component: z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>;
        role: z.ZodEnum<{
            SENSOR: "SENSOR";
            PRIMARY: "PRIMARY";
            TRANSCRIPT: "TRANSCRIPT";
            ANNOTATION: "ANNOTATION";
            CALIBRATION: "CALIBRATION";
            DOCUMENTATION: "DOCUMENTATION";
        }>;
        relativePath: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        groupId: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strict>, z.ZodObject<{
        operation: z.ZodLiteral<"REMOVE_MEMBER">;
        memberId: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        operation: z.ZodLiteral<"SET_MEMBER_ROLE">;
        memberId: z.ZodString;
        role: z.ZodEnum<{
            SENSOR: "SENSOR";
            PRIMARY: "PRIMARY";
            TRANSCRIPT: "TRANSCRIPT";
            ANNOTATION: "ANNOTATION";
            CALIBRATION: "CALIBRATION";
            DOCUMENTATION: "DOCUMENTATION";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        operation: z.ZodLiteral<"SET_MEMBER_GROUP">;
        memberId: z.ZodString;
        groupId: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        operation: z.ZodLiteral<"ADD_GROUP">;
        component: z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>;
        label: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        operation: z.ZodLiteral<"RENAME_GROUP">;
        groupId: z.ZodString;
        label: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        operation: z.ZodLiteral<"REMOVE_GROUP">;
        groupId: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        operation: z.ZodLiteral<"ADD_LINK">;
        component: z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>;
        kind: z.ZodEnum<{
            TRANSCRIPT_FOR: "TRANSCRIPT_FOR";
            ANNOTATION_FOR: "ANNOTATION_FOR";
            CALIBRATION_FOR: "CALIBRATION_FOR";
            SYNCHRONIZED_WITH: "SYNCHRONIZED_WITH";
            DOCUMENTATION_FOR: "DOCUMENTATION_FOR";
        }>;
        source: z.ZodObject<{
            memberId: z.ZodString;
            logicalEntryId: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>;
        target: z.ZodObject<{
            memberId: z.ZodString;
            logicalEntryId: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>;
        required: z.ZodBoolean;
    }, z.core.$strict>, z.ZodObject<{
        operation: z.ZodLiteral<"REMOVE_LINK">;
        linkId: z.ZodString;
    }, z.core.$strict>], "operation">>;
    expectedPreparationGeneration: z.ZodNumber;
}, z.core.$strict>;
export type DatasetFilesMutationBody = z.infer<typeof DatasetFilesMutationBodySchema>;
export declare const DatasetFilesContextBodySchema: z.ZodObject<{
    requestId: z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
    expectedPreparationGeneration: z.ZodNumber;
    expectedContentId: z.ZodNullable<z.ZodString>;
    expectedContentGeneration: z.ZodNullable<z.ZodNumber>;
    editContext: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        mode: z.ZodLiteral<"EXISTING_DRAFT">;
        expectedContentId: z.ZodString;
        expectedGeneration: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        mode: z.ZodLiteral<"INITIALIZE">;
        expectedWorkflowRevision: z.ZodNumber;
        context: z.ZodEnum<{
            REQUESTED_CHANGES: "REQUESTED_CHANGES";
            MANAGED_EDIT: "MANAGED_EDIT";
            APPROVED_REEDIT: "APPROVED_REEDIT";
            PLATFORM_WITHDRAWAL: "PLATFORM_WITHDRAWAL";
            PLATFORM_PUBLISHED_METADATA: "PLATFORM_PUBLISHED_METADATA";
        }>;
        expectedBaseContentId: z.ZodString;
    }, z.core.$strict>], "mode">>;
}, z.core.$strict>;
export declare const DatasetFilesUsageSchema: z.ZodObject<{
    state: z.ZodEnum<{
        UNAVAILABLE: "UNAVAILABLE";
        RECONCILING: "RECONCILING";
        ACCOUNTED: "ACCOUNTED";
    }>;
    dataset: z.ZodObject<{
        limitBytes: z.ZodLiteral<"5000000000" | "100000000000">;
        retainedBytes: z.ZodNullable<z.ZodString>;
        reservedBytes: z.ZodNullable<z.ZodString>;
        chargedBytes: z.ZodNullable<z.ZodString>;
        remainingBytes: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
    supplier: z.ZodObject<{
        limitBytes: z.ZodLiteral<"5000000000" | "100000000000">;
        retainedBytes: z.ZodNullable<z.ZodString>;
        reservedBytes: z.ZodNullable<z.ZodString>;
        chargedBytes: z.ZodNullable<z.ZodString>;
        remainingBytes: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const DatasetFilesContextResponseSchema: z.ZodObject<{
    contractVersion: z.ZodLiteral<1>;
    requestId: z.ZodOptional<z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>>;
    preparationId: z.ZodString;
    preparationGeneration: z.ZodNumber;
    contentId: z.ZodNullable<z.ZodString>;
    contentGeneration: z.ZodNullable<z.ZodNumber>;
    sourcePreparationGeneration: z.ZodNullable<z.ZodNumber>;
    serverUploadChoice: z.ZodNullable<z.ZodEnum<{
        SAMPLE_ONLY: "SAMPLE_ONLY";
        FULL_ONLY: "FULL_ONLY";
        FULL_AND_SAMPLE: "FULL_AND_SAMPLE";
    }>>;
    editable: z.ZodBoolean;
    synchronizationRequired: z.ZodBoolean;
    usage: z.ZodObject<{
        state: z.ZodEnum<{
            UNAVAILABLE: "UNAVAILABLE";
            RECONCILING: "RECONCILING";
            ACCOUNTED: "ACCOUNTED";
        }>;
        dataset: z.ZodObject<{
            limitBytes: z.ZodLiteral<"5000000000" | "100000000000">;
            retainedBytes: z.ZodNullable<z.ZodString>;
            reservedBytes: z.ZodNullable<z.ZodString>;
            chargedBytes: z.ZodNullable<z.ZodString>;
            remainingBytes: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>;
        supplier: z.ZodObject<{
            limitBytes: z.ZodLiteral<"5000000000" | "100000000000">;
            retainedBytes: z.ZodNullable<z.ZodString>;
            reservedBytes: z.ZodNullable<z.ZodString>;
            chargedBytes: z.ZodNullable<z.ZodString>;
            remainingBytes: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>;
    }, z.core.$strict>;
    admission: z.ZodObject<{
        enabled: z.ZodLiteral<false>;
        reason: z.ZodLiteral<"INTAKE_NOT_ENABLED">;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const DatasetFilesInventoryPageQuerySchema: z.ZodObject<{
    expectedPreparationGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
    contentId: z.ZodString;
    contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
    component: z.ZodOptional<z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>>;
    afterId: z.ZodOptional<z.ZodString>;
    limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
}, z.core.$strict>;
export declare const DatasetFilesInventoryMemberSchema: z.ZodObject<{
    id: z.ZodString;
    contentId: z.ZodString;
    uploadObjectId: z.ZodString;
    component: z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>;
    role: z.ZodEnum<{
        SENSOR: "SENSOR";
        PRIMARY: "PRIMARY";
        TRANSCRIPT: "TRANSCRIPT";
        ANNOTATION: "ANNOTATION";
        CALIBRATION: "CALIBRATION";
        DOCUMENTATION: "DOCUMENTATION";
    }>;
    relativePath: z.ZodNullable<z.ZodString>;
    groupId: z.ZodNullable<z.ZodString>;
    originalFileName: z.ZodNullable<z.ZodString>;
    measuredSizeBytes: z.ZodString;
    inspection: z.ZodObject<{
        securityState: z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            QUARANTINED: "QUARANTINED";
            PROCESSING: "PROCESSING";
            ACCEPTED: "ACCEPTED";
            BLOCKED: "BLOCKED";
            FAILED: "FAILED";
            CANCELLED: "CANCELLED";
            UNRECONCILED: "UNRECONCILED";
        }>;
        currentEvidenceId: z.ZodNullable<z.ZodString>;
        recordedOutcome: z.ZodEnum<{
            UNKNOWN: "UNKNOWN";
            NONE: "NONE";
            PASS: "PASS";
            FAIL: "FAIL";
        }>;
        current: z.ZodBoolean;
        eligibility: z.ZodLiteral<"NOT_EVALUATED">;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const DatasetFilesInventoryPageResponseSchema: z.ZodObject<{
    preparationId: z.ZodString;
    preparationGeneration: z.ZodNumber;
    contentId: z.ZodString;
    contentGeneration: z.ZodNumber;
    sourcePreparationGeneration: z.ZodNumber;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        contentId: z.ZodString;
        uploadObjectId: z.ZodString;
        component: z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>;
        role: z.ZodEnum<{
            SENSOR: "SENSOR";
            PRIMARY: "PRIMARY";
            TRANSCRIPT: "TRANSCRIPT";
            ANNOTATION: "ANNOTATION";
            CALIBRATION: "CALIBRATION";
            DOCUMENTATION: "DOCUMENTATION";
        }>;
        relativePath: z.ZodNullable<z.ZodString>;
        groupId: z.ZodNullable<z.ZodString>;
        originalFileName: z.ZodNullable<z.ZodString>;
        measuredSizeBytes: z.ZodString;
        inspection: z.ZodObject<{
            securityState: z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                QUARANTINED: "QUARANTINED";
                PROCESSING: "PROCESSING";
                ACCEPTED: "ACCEPTED";
                BLOCKED: "BLOCKED";
                FAILED: "FAILED";
                CANCELLED: "CANCELLED";
                UNRECONCILED: "UNRECONCILED";
            }>;
            currentEvidenceId: z.ZodNullable<z.ZodString>;
            recordedOutcome: z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                NONE: "NONE";
                PASS: "PASS";
                FAIL: "FAIL";
            }>;
            current: z.ZodBoolean;
            eligibility: z.ZodLiteral<"NOT_EVALUATED">;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    nextCursor: z.ZodNullable<z.ZodObject<{
        contentId: z.ZodString;
        contentGeneration: z.ZodNumber;
        afterId: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type DatasetFilesContextBody = z.infer<typeof DatasetFilesContextBodySchema>;
export declare const DatasetFilesOrganizationQuerySchema: z.ZodObject<{
    expectedPreparationGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
    contentId: z.ZodString;
    contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
    section: z.ZodEnum<{
        MEMBERS: "MEMBERS";
        GROUPS: "GROUPS";
        RELATIONSHIPS: "RELATIONSHIPS";
        INVENTORIES: "INVENTORIES";
        ENTRIES: "ENTRIES";
    }>;
    component: z.ZodOptional<z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>>;
    memberId: z.ZodOptional<z.ZodString>;
    inventoryId: z.ZodOptional<z.ZodString>;
    afterId: z.ZodOptional<z.ZodString>;
    limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
}, z.core.$strict>;
export declare const DatasetFilesOrganizationPageResponseSchema: z.ZodObject<{
    preparationId: z.ZodString;
    preparationGeneration: z.ZodNumber;
    contentId: z.ZodString;
    contentGeneration: z.ZodNumber;
    section: z.ZodEnum<{
        MEMBERS: "MEMBERS";
        GROUPS: "GROUPS";
        RELATIONSHIPS: "RELATIONSHIPS";
        INVENTORIES: "INVENTORIES";
        ENTRIES: "ENTRIES";
    }>;
    component: z.ZodNullable<z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>>;
    memberId: z.ZodNullable<z.ZodString>;
    inventoryId: z.ZodNullable<z.ZodString>;
    uploadObjectId: z.ZodNullable<z.ZodString>;
    items: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"MEMBER">;
        id: z.ZodString;
        uploadObjectId: z.ZodString;
        component: z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>;
        role: z.ZodEnum<{
            SENSOR: "SENSOR";
            PRIMARY: "PRIMARY";
            TRANSCRIPT: "TRANSCRIPT";
            ANNOTATION: "ANNOTATION";
            CALIBRATION: "CALIBRATION";
            DOCUMENTATION: "DOCUMENTATION";
        }>;
        originalFileName: z.ZodNullable<z.ZodString>;
        relativePath: z.ZodNullable<z.ZodString>;
        group: z.ZodNullable<z.ZodObject<{
            id: z.ZodString;
            label: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"GROUP">;
        id: z.ZodString;
        component: z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>;
        label: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"RELATIONSHIP">;
        id: z.ZodString;
        component: z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>;
        relationship: z.ZodEnum<{
            TRANSCRIPT_FOR: "TRANSCRIPT_FOR";
            ANNOTATION_FOR: "ANNOTATION_FOR";
            CALIBRATION_FOR: "CALIBRATION_FOR";
            SYNCHRONIZED_WITH: "SYNCHRONIZED_WITH";
            DOCUMENTATION_FOR: "DOCUMENTATION_FOR";
        }>;
        required: z.ZodBoolean;
        source: z.ZodObject<{
            memberId: z.ZodString;
            logicalEntryId: z.ZodNullable<z.ZodString>;
            displayName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            logicalEntry: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                id: z.ZodString;
                inventoryId: z.ZodString;
                locator: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    kind: z.ZodLiteral<"ARCHIVE_ENTRY">;
                    path: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    kind: z.ZodLiteral<"WORKBOOK_SHEET">;
                    sheetName: z.ZodString;
                }, z.core.$strict>], "kind">;
            }, z.core.$strict>>>;
        }, z.core.$strict>;
        target: z.ZodObject<{
            memberId: z.ZodString;
            logicalEntryId: z.ZodNullable<z.ZodString>;
            displayName: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            logicalEntry: z.ZodOptional<z.ZodNullable<z.ZodObject<{
                id: z.ZodString;
                inventoryId: z.ZodString;
                locator: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    kind: z.ZodLiteral<"ARCHIVE_ENTRY">;
                    path: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    kind: z.ZodLiteral<"WORKBOOK_SHEET">;
                    sheetName: z.ZodString;
                }, z.core.$strict>], "kind">;
            }, z.core.$strict>>>;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"INVENTORY">;
        id: z.ZodString;
        uploadObjectId: z.ZodString;
        structuralDigest: z.ZodString;
        sealedAt: z.ZodISODateTime;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"ENTRY">;
        id: z.ZodString;
        inventoryId: z.ZodString;
        uploadObjectId: z.ZodString;
        locator: z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"ARCHIVE_ENTRY">;
            path: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"WORKBOOK_SHEET">;
            sheetName: z.ZodString;
        }, z.core.$strict>], "kind">;
    }, z.core.$strict>], "kind">>;
    nextCursor: z.ZodNullable<z.ZodObject<{
        expectedPreparationGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
        contentId: z.ZodString;
        contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
        section: z.ZodEnum<{
            MEMBERS: "MEMBERS";
            GROUPS: "GROUPS";
            RELATIONSHIPS: "RELATIONSHIPS";
            INVENTORIES: "INVENTORIES";
            ENTRIES: "ENTRIES";
        }>;
        component: z.ZodOptional<z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>>;
        memberId: z.ZodOptional<z.ZodString>;
        inventoryId: z.ZodOptional<z.ZodString>;
        limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
        afterId: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type DatasetFilesOrganizationQuery = z.infer<typeof DatasetFilesOrganizationQuerySchema>;
export type DatasetFilesOrganizationPageResponse = z.infer<typeof DatasetFilesOrganizationPageResponseSchema>;
export type DatasetFilesContextResponse = z.infer<typeof DatasetFilesContextResponseSchema>;
export type DatasetFilesUsage = z.infer<typeof DatasetFilesUsageSchema>;
export type DatasetFilesInventoryPageQuery = z.infer<typeof DatasetFilesInventoryPageQuerySchema>;
export type DatasetFilesInventoryPageResponse = z.infer<typeof DatasetFilesInventoryPageResponseSchema>;
export declare const DatasetFrozenInventoryQuerySchema: z.ZodObject<{
    expectedWorkflowRevision: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
    contentId: z.ZodString;
    contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
    inventory: z.ZodDefault<z.ZodEnum<{
        GROUPS: "GROUPS";
        RELATIONSHIPS: "RELATIONSHIPS";
        FILES: "FILES";
    }>>;
    component: z.ZodOptional<z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>>;
    afterId: z.ZodOptional<z.ZodString>;
    limit: z.ZodDefault<z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>>;
}, z.core.$strict>;
export declare const DatasetFrozenInventoryResponseSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    inventory: z.ZodLiteral<"FILES">;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        contentId: z.ZodString;
        uploadObjectId: z.ZodString;
        component: z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>;
        role: z.ZodEnum<{
            SENSOR: "SENSOR";
            PRIMARY: "PRIMARY";
            TRANSCRIPT: "TRANSCRIPT";
            ANNOTATION: "ANNOTATION";
            CALIBRATION: "CALIBRATION";
            DOCUMENTATION: "DOCUMENTATION";
        }>;
        relativePath: z.ZodNullable<z.ZodString>;
        groupId: z.ZodNullable<z.ZodString>;
        originalFileName: z.ZodNullable<z.ZodString>;
        measuredSizeBytes: z.ZodString;
        inspection: z.ZodObject<{
            securityState: z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                QUARANTINED: "QUARANTINED";
                PROCESSING: "PROCESSING";
                ACCEPTED: "ACCEPTED";
                BLOCKED: "BLOCKED";
                FAILED: "FAILED";
                CANCELLED: "CANCELLED";
                UNRECONCILED: "UNRECONCILED";
            }>;
            currentEvidenceId: z.ZodNullable<z.ZodString>;
            recordedOutcome: z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                NONE: "NONE";
                PASS: "PASS";
                FAIL: "FAIL";
            }>;
            current: z.ZodBoolean;
            eligibility: z.ZodLiteral<"NOT_EVALUATED">;
        }, z.core.$strict>;
        inspectionAtSubmissionId: z.ZodString;
    }, z.core.$strict>>;
    datasetId: z.ZodString;
    workflowRevision: z.ZodNumber;
    contentId: z.ZodString;
    contentGeneration: z.ZodNumber;
    frozenAt: z.ZodString;
    total: z.ZodNumber;
    component: z.ZodNullable<z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>>;
    nextCursor: z.ZodNullable<z.ZodObject<{
        expectedWorkflowRevision: z.ZodNumber;
        contentId: z.ZodString;
        contentGeneration: z.ZodNumber;
        afterId: z.ZodString;
        inventory: z.ZodEnum<{
            GROUPS: "GROUPS";
            RELATIONSHIPS: "RELATIONSHIPS";
            FILES: "FILES";
        }>;
        component: z.ZodOptional<z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>>;
    }, z.core.$strict>>;
}, z.core.$strict>, z.ZodObject<{
    inventory: z.ZodLiteral<"GROUPS">;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        contentId: z.ZodString;
        component: z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>;
        label: z.ZodString;
    }, z.core.$strict>>;
    datasetId: z.ZodString;
    workflowRevision: z.ZodNumber;
    contentId: z.ZodString;
    contentGeneration: z.ZodNumber;
    frozenAt: z.ZodString;
    total: z.ZodNumber;
    component: z.ZodNullable<z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>>;
    nextCursor: z.ZodNullable<z.ZodObject<{
        expectedWorkflowRevision: z.ZodNumber;
        contentId: z.ZodString;
        contentGeneration: z.ZodNumber;
        afterId: z.ZodString;
        inventory: z.ZodEnum<{
            GROUPS: "GROUPS";
            RELATIONSHIPS: "RELATIONSHIPS";
            FILES: "FILES";
        }>;
        component: z.ZodOptional<z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>>;
    }, z.core.$strict>>;
}, z.core.$strict>, z.ZodObject<{
    inventory: z.ZodLiteral<"RELATIONSHIPS">;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        contentId: z.ZodString;
        component: z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>;
        kind: z.ZodEnum<{
            TRANSCRIPT_FOR: "TRANSCRIPT_FOR";
            ANNOTATION_FOR: "ANNOTATION_FOR";
            CALIBRATION_FOR: "CALIBRATION_FOR";
            SYNCHRONIZED_WITH: "SYNCHRONIZED_WITH";
            DOCUMENTATION_FOR: "DOCUMENTATION_FOR";
        }>;
        required: z.ZodBoolean;
        source: z.ZodObject<{
            memberId: z.ZodString;
            uploadObjectId: z.ZodString;
            logicalEntry: z.ZodNullable<z.ZodObject<{
                id: z.ZodString;
                inventoryId: z.ZodString;
                locator: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    kind: z.ZodLiteral<"ARCHIVE_ENTRY">;
                    path: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    kind: z.ZodLiteral<"WORKBOOK_SHEET">;
                    sheetName: z.ZodString;
                }, z.core.$strict>], "kind">;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        target: z.ZodObject<{
            memberId: z.ZodString;
            uploadObjectId: z.ZodString;
            logicalEntry: z.ZodNullable<z.ZodObject<{
                id: z.ZodString;
                inventoryId: z.ZodString;
                locator: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    kind: z.ZodLiteral<"ARCHIVE_ENTRY">;
                    path: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    kind: z.ZodLiteral<"WORKBOOK_SHEET">;
                    sheetName: z.ZodString;
                }, z.core.$strict>], "kind">;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    datasetId: z.ZodString;
    workflowRevision: z.ZodNumber;
    contentId: z.ZodString;
    contentGeneration: z.ZodNumber;
    frozenAt: z.ZodString;
    total: z.ZodNumber;
    component: z.ZodNullable<z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>>;
    nextCursor: z.ZodNullable<z.ZodObject<{
        expectedWorkflowRevision: z.ZodNumber;
        contentId: z.ZodString;
        contentGeneration: z.ZodNumber;
        afterId: z.ZodString;
        inventory: z.ZodEnum<{
            GROUPS: "GROUPS";
            RELATIONSHIPS: "RELATIONSHIPS";
            FILES: "FILES";
        }>;
        component: z.ZodOptional<z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>>;
    }, z.core.$strict>>;
}, z.core.$strict>], "inventory">;
export type DatasetFrozenInventoryQuery = z.infer<typeof DatasetFrozenInventoryQuerySchema>;
//# sourceMappingURL=files.schema.d.ts.map