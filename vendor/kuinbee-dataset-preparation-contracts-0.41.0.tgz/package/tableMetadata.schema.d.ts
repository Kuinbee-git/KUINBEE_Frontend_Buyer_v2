import { z } from "zod";
export declare const DatasetTableMetadataTableSchema: z.ZodObject<{
    kind: z.ZodLiteral<"TABLE">;
    id: z.ZodString;
    applicability: z.ZodObject<{
        purpose: z.ZodEnum<{
            SENSOR: "SENSOR";
            PRIMARY: "PRIMARY";
            TRANSCRIPT: "TRANSCRIPT";
            ANNOTATION: "ANNOTATION";
            CALIBRATION: "CALIBRATION";
            DOCUMENTATION: "DOCUMENTATION";
            COMPANION: "COMPANION";
        }>;
        companionPurposes: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            TRANSCRIPT: "TRANSCRIPT";
            ANNOTATION: "ANNOTATION";
            CALIBRATION: "CALIBRATION";
            DOCUMENTATION: "DOCUMENTATION";
        }>>>;
        origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
        basis: z.ZodEnum<{
            SELECTED_FILE_PURPOSE: "SELECTED_FILE_PURPOSE";
            EXACT_ENTRY_RELATIONSHIP: "EXACT_ENTRY_RELATIONSHIP";
        }>;
        definitionsRequired: z.ZodBoolean;
    }, z.core.$strict>;
    component: z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>;
    displayName: z.ZodNullable<z.ZodString>;
    recordUnit: z.ZodNullable<z.ZodString>;
    missingValues: z.ZodObject<{
        state: z.ZodNullable<z.ZodType<string, unknown, z.core.$ZodTypeInternals<string, unknown>>>;
        value: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
    observed: z.ZodObject<{
        origin: z.ZodLiteral<"BACKEND_OBSERVED">;
        scope: z.ZodLiteral<"EXACT_TABLE">;
        dataRecordCount: z.ZodString;
        columnCount: z.ZodNumber;
        headerConvention: z.ZodEnum<{
            PRESENT: "PRESENT";
            ABSENT: "ABSENT";
        }>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const DatasetTableMetadataColumnSchema: z.ZodObject<{
    kind: z.ZodLiteral<"COLUMN">;
    id: z.ZodString;
    tableId: z.ZodString;
    position: z.ZodNumber;
    observedName: z.ZodNullable<z.ZodString>;
    storageRepresentation: z.ZodLiteral<"UTF8_TEXT">;
    meaning: z.ZodObject<{
        state: z.ZodNullable<z.ZodType<string, unknown, z.core.$ZodTypeInternals<string, unknown>>>;
        value: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
    declaredType: z.ZodNullable<z.ZodEnum<{
        TEXT: "TEXT";
        UNKNOWN: "UNKNOWN";
        OTHER: "OTHER";
        IDENTIFIER: "IDENTIFIER";
        CATEGORY: "CATEGORY";
        INTEGER: "INTEGER";
        DECIMAL: "DECIMAL";
        BOOLEAN: "BOOLEAN";
        DATE: "DATE";
        DATETIME: "DATETIME";
        COORDINATE: "COORDINATE";
    }>>;
    unit: z.ZodObject<{
        state: z.ZodNullable<z.ZodType<string, unknown, z.core.$ZodTypeInternals<string, unknown>>>;
        value: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const DatasetTableMetadataCursorSchema: z.ZodObject<{
    contentId: z.ZodString;
    contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
    component: z.ZodOptional<z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>>;
    tableId: z.ZodOptional<z.ZodString>;
    afterId: z.ZodOptional<z.ZodString>;
    limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
}, z.core.$strict>;
export declare const DatasetTableMetadataPageSchema: z.ZodObject<{
    contentId: z.ZodString;
    contentGeneration: z.ZodNumber;
    frozen: z.ZodBoolean;
    frozenAt: z.ZodNullable<z.ZodString>;
    component: z.ZodNullable<z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>>;
    tableId: z.ZodNullable<z.ZodString>;
    table: z.ZodNullable<z.ZodObject<{
        kind: z.ZodLiteral<"TABLE">;
        id: z.ZodString;
        applicability: z.ZodObject<{
            purpose: z.ZodEnum<{
                SENSOR: "SENSOR";
                PRIMARY: "PRIMARY";
                TRANSCRIPT: "TRANSCRIPT";
                ANNOTATION: "ANNOTATION";
                CALIBRATION: "CALIBRATION";
                DOCUMENTATION: "DOCUMENTATION";
                COMPANION: "COMPANION";
            }>;
            companionPurposes: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                TRANSCRIPT: "TRANSCRIPT";
                ANNOTATION: "ANNOTATION";
                CALIBRATION: "CALIBRATION";
                DOCUMENTATION: "DOCUMENTATION";
            }>>>;
            origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
            basis: z.ZodEnum<{
                SELECTED_FILE_PURPOSE: "SELECTED_FILE_PURPOSE";
                EXACT_ENTRY_RELATIONSHIP: "EXACT_ENTRY_RELATIONSHIP";
            }>;
            definitionsRequired: z.ZodBoolean;
        }, z.core.$strict>;
        component: z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>;
        displayName: z.ZodNullable<z.ZodString>;
        recordUnit: z.ZodNullable<z.ZodString>;
        missingValues: z.ZodObject<{
            state: z.ZodNullable<z.ZodType<string, unknown, z.core.$ZodTypeInternals<string, unknown>>>;
            value: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>;
        observed: z.ZodObject<{
            origin: z.ZodLiteral<"BACKEND_OBSERVED">;
            scope: z.ZodLiteral<"EXACT_TABLE">;
            dataRecordCount: z.ZodString;
            columnCount: z.ZodNumber;
            headerConvention: z.ZodEnum<{
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
            }>;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    items: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"TABLE">;
        id: z.ZodString;
        applicability: z.ZodObject<{
            purpose: z.ZodEnum<{
                SENSOR: "SENSOR";
                PRIMARY: "PRIMARY";
                TRANSCRIPT: "TRANSCRIPT";
                ANNOTATION: "ANNOTATION";
                CALIBRATION: "CALIBRATION";
                DOCUMENTATION: "DOCUMENTATION";
                COMPANION: "COMPANION";
            }>;
            companionPurposes: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                TRANSCRIPT: "TRANSCRIPT";
                ANNOTATION: "ANNOTATION";
                CALIBRATION: "CALIBRATION";
                DOCUMENTATION: "DOCUMENTATION";
            }>>>;
            origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
            basis: z.ZodEnum<{
                SELECTED_FILE_PURPOSE: "SELECTED_FILE_PURPOSE";
                EXACT_ENTRY_RELATIONSHIP: "EXACT_ENTRY_RELATIONSHIP";
            }>;
            definitionsRequired: z.ZodBoolean;
        }, z.core.$strict>;
        component: z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>;
        displayName: z.ZodNullable<z.ZodString>;
        recordUnit: z.ZodNullable<z.ZodString>;
        missingValues: z.ZodObject<{
            state: z.ZodNullable<z.ZodType<string, unknown, z.core.$ZodTypeInternals<string, unknown>>>;
            value: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>;
        observed: z.ZodObject<{
            origin: z.ZodLiteral<"BACKEND_OBSERVED">;
            scope: z.ZodLiteral<"EXACT_TABLE">;
            dataRecordCount: z.ZodString;
            columnCount: z.ZodNumber;
            headerConvention: z.ZodEnum<{
                PRESENT: "PRESENT";
                ABSENT: "ABSENT";
            }>;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"COLUMN">;
        id: z.ZodString;
        tableId: z.ZodString;
        position: z.ZodNumber;
        observedName: z.ZodNullable<z.ZodString>;
        storageRepresentation: z.ZodLiteral<"UTF8_TEXT">;
        meaning: z.ZodObject<{
            state: z.ZodNullable<z.ZodType<string, unknown, z.core.$ZodTypeInternals<string, unknown>>>;
            value: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>;
        declaredType: z.ZodNullable<z.ZodEnum<{
            TEXT: "TEXT";
            UNKNOWN: "UNKNOWN";
            OTHER: "OTHER";
            IDENTIFIER: "IDENTIFIER";
            CATEGORY: "CATEGORY";
            INTEGER: "INTEGER";
            DECIMAL: "DECIMAL";
            BOOLEAN: "BOOLEAN";
            DATE: "DATE";
            DATETIME: "DATETIME";
            COORDINATE: "COORDINATE";
        }>>;
        unit: z.ZodObject<{
            state: z.ZodNullable<z.ZodType<string, unknown, z.core.$ZodTypeInternals<string, unknown>>>;
            value: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>;
    }, z.core.$strict>], "kind">>;
    nextCursor: z.ZodNullable<z.ZodObject<{
        contentId: z.ZodString;
        contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
        component: z.ZodOptional<z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>>;
        tableId: z.ZodOptional<z.ZodString>;
        afterId: z.ZodOptional<z.ZodString>;
        limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetPrivateTableMetadataQuerySchema: z.ZodObject<{
    afterId: z.ZodOptional<z.ZodString>;
    limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    scope: z.ZodEnum<{
        PUBLISHED: "PUBLISHED";
        WORKING: "WORKING";
        REVIEWED: "REVIEWED";
        EDIT_BASE: "EDIT_BASE";
        GRANTED: "GRANTED";
    }>;
    component: z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>;
    editOperation: z.ZodOptional<z.ZodEnum<{
        METADATA: "METADATA";
        PRICING: "PRICING";
        MATERIALS: "MATERIALS";
    }>>;
    contentId: z.ZodString;
    contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
    expectedWorkflowRevision: z.ZodOptional<z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>>;
    memberId: z.ZodOptional<z.ZodString>;
    tableId: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const DatasetPrivateTableMetadataResponseSchema: z.ZodObject<{
    context: z.ZodObject<{
        datasetId: z.ZodString;
        scope: z.ZodEnum<{
            PUBLISHED: "PUBLISHED";
            WORKING: "WORKING";
            REVIEWED: "REVIEWED";
            EDIT_BASE: "EDIT_BASE";
            GRANTED: "GRANTED";
        }>;
        component: z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>;
        editOperation: z.ZodNullable<z.ZodEnum<{
            METADATA: "METADATA";
            PRICING: "PRICING";
            MATERIALS: "MATERIALS";
        }>>;
        contentId: z.ZodString;
        contentGeneration: z.ZodNumber;
        workflowRevision: z.ZodNullable<z.ZodNumber>;
        frozen: z.ZodBoolean;
        publicationId: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
    memberId: z.ZodNullable<z.ZodString>;
    page: z.ZodObject<{
        contentId: z.ZodString;
        contentGeneration: z.ZodNumber;
        frozen: z.ZodBoolean;
        frozenAt: z.ZodNullable<z.ZodString>;
        component: z.ZodNullable<z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>>;
        tableId: z.ZodNullable<z.ZodString>;
        table: z.ZodNullable<z.ZodObject<{
            kind: z.ZodLiteral<"TABLE">;
            id: z.ZodString;
            applicability: z.ZodObject<{
                purpose: z.ZodEnum<{
                    SENSOR: "SENSOR";
                    PRIMARY: "PRIMARY";
                    TRANSCRIPT: "TRANSCRIPT";
                    ANNOTATION: "ANNOTATION";
                    CALIBRATION: "CALIBRATION";
                    DOCUMENTATION: "DOCUMENTATION";
                    COMPANION: "COMPANION";
                }>;
                companionPurposes: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                    TRANSCRIPT: "TRANSCRIPT";
                    ANNOTATION: "ANNOTATION";
                    CALIBRATION: "CALIBRATION";
                    DOCUMENTATION: "DOCUMENTATION";
                }>>>;
                origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
                basis: z.ZodEnum<{
                    SELECTED_FILE_PURPOSE: "SELECTED_FILE_PURPOSE";
                    EXACT_ENTRY_RELATIONSHIP: "EXACT_ENTRY_RELATIONSHIP";
                }>;
                definitionsRequired: z.ZodBoolean;
            }, z.core.$strict>;
            component: z.ZodEnum<{
                FULL: "FULL";
                SAMPLE: "SAMPLE";
            }>;
            displayName: z.ZodNullable<z.ZodString>;
            recordUnit: z.ZodNullable<z.ZodString>;
            missingValues: z.ZodObject<{
                state: z.ZodNullable<z.ZodType<string, unknown, z.core.$ZodTypeInternals<string, unknown>>>;
                value: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>;
            observed: z.ZodObject<{
                origin: z.ZodLiteral<"BACKEND_OBSERVED">;
                scope: z.ZodLiteral<"EXACT_TABLE">;
                dataRecordCount: z.ZodString;
                columnCount: z.ZodNumber;
                headerConvention: z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
        items: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"TABLE">;
            id: z.ZodString;
            applicability: z.ZodObject<{
                purpose: z.ZodEnum<{
                    SENSOR: "SENSOR";
                    PRIMARY: "PRIMARY";
                    TRANSCRIPT: "TRANSCRIPT";
                    ANNOTATION: "ANNOTATION";
                    CALIBRATION: "CALIBRATION";
                    DOCUMENTATION: "DOCUMENTATION";
                    COMPANION: "COMPANION";
                }>;
                companionPurposes: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                    TRANSCRIPT: "TRANSCRIPT";
                    ANNOTATION: "ANNOTATION";
                    CALIBRATION: "CALIBRATION";
                    DOCUMENTATION: "DOCUMENTATION";
                }>>>;
                origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
                basis: z.ZodEnum<{
                    SELECTED_FILE_PURPOSE: "SELECTED_FILE_PURPOSE";
                    EXACT_ENTRY_RELATIONSHIP: "EXACT_ENTRY_RELATIONSHIP";
                }>;
                definitionsRequired: z.ZodBoolean;
            }, z.core.$strict>;
            component: z.ZodEnum<{
                FULL: "FULL";
                SAMPLE: "SAMPLE";
            }>;
            displayName: z.ZodNullable<z.ZodString>;
            recordUnit: z.ZodNullable<z.ZodString>;
            missingValues: z.ZodObject<{
                state: z.ZodNullable<z.ZodType<string, unknown, z.core.$ZodTypeInternals<string, unknown>>>;
                value: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>;
            observed: z.ZodObject<{
                origin: z.ZodLiteral<"BACKEND_OBSERVED">;
                scope: z.ZodLiteral<"EXACT_TABLE">;
                dataRecordCount: z.ZodString;
                columnCount: z.ZodNumber;
                headerConvention: z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>;
            }, z.core.$strict>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"COLUMN">;
            id: z.ZodString;
            tableId: z.ZodString;
            position: z.ZodNumber;
            observedName: z.ZodNullable<z.ZodString>;
            storageRepresentation: z.ZodLiteral<"UTF8_TEXT">;
            meaning: z.ZodObject<{
                state: z.ZodNullable<z.ZodType<string, unknown, z.core.$ZodTypeInternals<string, unknown>>>;
                value: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>;
            declaredType: z.ZodNullable<z.ZodEnum<{
                TEXT: "TEXT";
                UNKNOWN: "UNKNOWN";
                OTHER: "OTHER";
                IDENTIFIER: "IDENTIFIER";
                CATEGORY: "CATEGORY";
                INTEGER: "INTEGER";
                DECIMAL: "DECIMAL";
                BOOLEAN: "BOOLEAN";
                DATE: "DATE";
                DATETIME: "DATETIME";
                COORDINATE: "COORDINATE";
            }>>;
            unit: z.ZodObject<{
                state: z.ZodNullable<z.ZodType<string, unknown, z.core.$ZodTypeInternals<string, unknown>>>;
                value: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>;
        }, z.core.$strict>], "kind">>;
        nextCursor: z.ZodNullable<z.ZodObject<{
            contentId: z.ZodString;
            contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
            component: z.ZodOptional<z.ZodEnum<{
                FULL: "FULL";
                SAMPLE: "SAMPLE";
            }>>;
            tableId: z.ZodOptional<z.ZodString>;
            afterId: z.ZodOptional<z.ZodString>;
            limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    targets: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        memberId: z.ZodString;
        observedTableId: z.ZodString;
        evidenceId: z.ZodString;
        locator: z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"ARCHIVE_ENTRY">;
            path: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"WORKBOOK_SHEET">;
            sheetName: z.ZodString;
        }, z.core.$strict>], "kind">>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetPublicTableMetadataQuerySchema: z.ZodObject<{
    publicationId: z.ZodString;
    contentId: z.ZodString;
    contentGeneration: z.ZodOptional<z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>>;
    component: z.ZodOptional<z.ZodEnum<{
        FULL: "FULL";
        SAMPLE: "SAMPLE";
    }>>;
    tableId: z.ZodOptional<z.ZodString>;
    afterId: z.ZodOptional<z.ZodString>;
    limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
}, z.core.$strict>;
export declare const DatasetPublicTableMetadataResponseSchema: z.ZodObject<{
    datasetId: z.ZodString;
    publicationId: z.ZodString;
    page: z.ZodObject<{
        contentId: z.ZodString;
        contentGeneration: z.ZodNumber;
        frozen: z.ZodBoolean;
        frozenAt: z.ZodNullable<z.ZodString>;
        component: z.ZodNullable<z.ZodEnum<{
            FULL: "FULL";
            SAMPLE: "SAMPLE";
        }>>;
        tableId: z.ZodNullable<z.ZodString>;
        table: z.ZodNullable<z.ZodObject<{
            kind: z.ZodLiteral<"TABLE">;
            id: z.ZodString;
            applicability: z.ZodObject<{
                purpose: z.ZodEnum<{
                    SENSOR: "SENSOR";
                    PRIMARY: "PRIMARY";
                    TRANSCRIPT: "TRANSCRIPT";
                    ANNOTATION: "ANNOTATION";
                    CALIBRATION: "CALIBRATION";
                    DOCUMENTATION: "DOCUMENTATION";
                    COMPANION: "COMPANION";
                }>;
                companionPurposes: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                    TRANSCRIPT: "TRANSCRIPT";
                    ANNOTATION: "ANNOTATION";
                    CALIBRATION: "CALIBRATION";
                    DOCUMENTATION: "DOCUMENTATION";
                }>>>;
                origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
                basis: z.ZodEnum<{
                    SELECTED_FILE_PURPOSE: "SELECTED_FILE_PURPOSE";
                    EXACT_ENTRY_RELATIONSHIP: "EXACT_ENTRY_RELATIONSHIP";
                }>;
                definitionsRequired: z.ZodBoolean;
            }, z.core.$strict>;
            component: z.ZodEnum<{
                FULL: "FULL";
                SAMPLE: "SAMPLE";
            }>;
            displayName: z.ZodNullable<z.ZodString>;
            recordUnit: z.ZodNullable<z.ZodString>;
            missingValues: z.ZodObject<{
                state: z.ZodNullable<z.ZodType<string, unknown, z.core.$ZodTypeInternals<string, unknown>>>;
                value: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>;
            observed: z.ZodObject<{
                origin: z.ZodLiteral<"BACKEND_OBSERVED">;
                scope: z.ZodLiteral<"EXACT_TABLE">;
                dataRecordCount: z.ZodString;
                columnCount: z.ZodNumber;
                headerConvention: z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
        items: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"TABLE">;
            id: z.ZodString;
            applicability: z.ZodObject<{
                purpose: z.ZodEnum<{
                    SENSOR: "SENSOR";
                    PRIMARY: "PRIMARY";
                    TRANSCRIPT: "TRANSCRIPT";
                    ANNOTATION: "ANNOTATION";
                    CALIBRATION: "CALIBRATION";
                    DOCUMENTATION: "DOCUMENTATION";
                    COMPANION: "COMPANION";
                }>;
                companionPurposes: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                    TRANSCRIPT: "TRANSCRIPT";
                    ANNOTATION: "ANNOTATION";
                    CALIBRATION: "CALIBRATION";
                    DOCUMENTATION: "DOCUMENTATION";
                }>>>;
                origin: z.ZodLiteral<"SUPPLIER_DECLARED">;
                basis: z.ZodEnum<{
                    SELECTED_FILE_PURPOSE: "SELECTED_FILE_PURPOSE";
                    EXACT_ENTRY_RELATIONSHIP: "EXACT_ENTRY_RELATIONSHIP";
                }>;
                definitionsRequired: z.ZodBoolean;
            }, z.core.$strict>;
            component: z.ZodEnum<{
                FULL: "FULL";
                SAMPLE: "SAMPLE";
            }>;
            displayName: z.ZodNullable<z.ZodString>;
            recordUnit: z.ZodNullable<z.ZodString>;
            missingValues: z.ZodObject<{
                state: z.ZodNullable<z.ZodType<string, unknown, z.core.$ZodTypeInternals<string, unknown>>>;
                value: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>;
            observed: z.ZodObject<{
                origin: z.ZodLiteral<"BACKEND_OBSERVED">;
                scope: z.ZodLiteral<"EXACT_TABLE">;
                dataRecordCount: z.ZodString;
                columnCount: z.ZodNumber;
                headerConvention: z.ZodEnum<{
                    PRESENT: "PRESENT";
                    ABSENT: "ABSENT";
                }>;
            }, z.core.$strict>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"COLUMN">;
            id: z.ZodString;
            tableId: z.ZodString;
            position: z.ZodNumber;
            observedName: z.ZodNullable<z.ZodString>;
            storageRepresentation: z.ZodLiteral<"UTF8_TEXT">;
            meaning: z.ZodObject<{
                state: z.ZodNullable<z.ZodType<string, unknown, z.core.$ZodTypeInternals<string, unknown>>>;
                value: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>;
            declaredType: z.ZodNullable<z.ZodEnum<{
                TEXT: "TEXT";
                UNKNOWN: "UNKNOWN";
                OTHER: "OTHER";
                IDENTIFIER: "IDENTIFIER";
                CATEGORY: "CATEGORY";
                INTEGER: "INTEGER";
                DECIMAL: "DECIMAL";
                BOOLEAN: "BOOLEAN";
                DATE: "DATE";
                DATETIME: "DATETIME";
                COORDINATE: "COORDINATE";
            }>>;
            unit: z.ZodObject<{
                state: z.ZodNullable<z.ZodType<string, unknown, z.core.$ZodTypeInternals<string, unknown>>>;
                value: z.ZodNullable<z.ZodString>;
            }, z.core.$strict>;
        }, z.core.$strict>], "kind">>;
        nextCursor: z.ZodNullable<z.ZodObject<{
            contentId: z.ZodString;
            contentGeneration: z.ZodUnion<readonly [z.ZodNumber, z.ZodPipe<z.ZodPipe<z.ZodString, z.ZodTransform<number, string>>, z.ZodNumber>]>;
            component: z.ZodOptional<z.ZodEnum<{
                FULL: "FULL";
                SAMPLE: "SAMPLE";
            }>>;
            tableId: z.ZodOptional<z.ZodString>;
            afterId: z.ZodOptional<z.ZodString>;
            limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export type DatasetTableMetadataCursor = z.infer<typeof DatasetTableMetadataCursorSchema>;
export type DatasetTableMetadataPage = z.infer<typeof DatasetTableMetadataPageSchema>;
export type DatasetPrivateTableMetadataQuery = z.infer<typeof DatasetPrivateTableMetadataQuerySchema>;
export type DatasetPrivateTableMetadataResponse = z.infer<typeof DatasetPrivateTableMetadataResponseSchema>;
export type DatasetPublicTableMetadataQuery = z.infer<typeof DatasetPublicTableMetadataQuerySchema>;
export type DatasetPublicTableMetadataResponse = z.infer<typeof DatasetPublicTableMetadataResponseSchema>;
//# sourceMappingURL=tableMetadata.schema.d.ts.map