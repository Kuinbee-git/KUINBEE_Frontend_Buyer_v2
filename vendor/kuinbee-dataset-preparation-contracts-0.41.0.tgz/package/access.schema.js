"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DatasetFileBundleManifestSchema = exports.DatasetFileBundleQuerySchema = exports.DatasetFileDownloadResponseSchema = exports.DatasetFileObservationResponseSchema = exports.DatasetFileObservationSchema = exports.DatasetFileObservationQuerySchema = exports.DatasetFileAccessPageResponseSchema = exports.DatasetFileAccessMemberSchema = exports.DatasetFileDownloadBodySchema = exports.DatasetFileAccessPageQuerySchema = exports.DatasetFileAccessContextQuerySchema = exports.DatasetFileAccessContextSchema = exports.DatasetFileAccessSelectionSchema = exports.DatasetFileAccessScopeSchema = void 0;
const zod_1 = require("zod");
const content_schema_1 = require("./content.schema");
const files_schema_1 = require("./files.schema");
const id = zod_1.z.string().cuid();
const revision = zod_1.z.number().int().min(0).max(2_147_483_647);
const queryRevision = zod_1.z.union([revision, zod_1.z.string().regex(/^(0|[1-9][0-9]{0,9})$/).transform(Number).pipe(revision)]);
const bytes = zod_1.z.string().regex(/^(0|[1-9][0-9]{0,18})$/);
exports.DatasetFileAccessScopeSchema = zod_1.z.enum(["WORKING", "REVIEWED", "PUBLISHED", "EDIT_BASE", "GRANTED"]);
exports.DatasetFileAccessSelectionSchema = zod_1.z.object({ scope: exports.DatasetFileAccessScopeSchema,
    component: content_schema_1.DatasetMaterialComponentSchema, editOperation: zod_1.z.enum(["METADATA", "PRICING", "MATERIALS"]).optional() }).strict()
    .refine(value => value.scope === "EDIT_BASE" || value.editOperation === undefined, "Edit operation applies only to the permitted edit base");
exports.DatasetFileAccessContextSchema = zod_1.z.object({ datasetId: id, scope: exports.DatasetFileAccessScopeSchema,
    component: content_schema_1.DatasetMaterialComponentSchema, editOperation: zod_1.z.enum(["METADATA", "PRICING", "MATERIALS"]).nullable(),
    contentId: id, contentGeneration: revision, workflowRevision: revision.nullable(), frozen: zod_1.z.boolean(),
    publicationId: id.nullable(),
}).strict().refine(value => value.scope === "GRANTED" ? value.workflowRevision === null && value.component === "FULL" && value.frozen :
    value.workflowRevision !== null, "Granted files retain their historical content independently of the current workflow");
exports.DatasetFileAccessContextQuerySchema = exports.DatasetFileAccessSelectionSchema;
const exact = {
    scope: exports.DatasetFileAccessScopeSchema, component: content_schema_1.DatasetMaterialComponentSchema,
    editOperation: zod_1.z.enum(["METADATA", "PRICING", "MATERIALS"]).optional(),
    contentId: id, contentGeneration: queryRevision,
    expectedWorkflowRevision: queryRevision.optional(),
};
exports.DatasetFileAccessPageQuerySchema = zod_1.z.object({ ...exact, afterId: id.optional(),
    limit: zod_1.z.coerce.number().int().min(1).max(50).default(20) }).strict();
exports.DatasetFileDownloadBodySchema = zod_1.z.object({
    scope: exports.DatasetFileAccessScopeSchema, component: content_schema_1.DatasetMaterialComponentSchema,
    editOperation: zod_1.z.enum(["METADATA", "PRICING", "MATERIALS"]).optional(),
    contentId: id, contentGeneration: revision, expectedWorkflowRevision: revision.optional(), memberId: id,
    // A correlation value, not a durable grant or a promise to replay an old URL.
    // Every request (including retries) rechecks current authorization/security.
    downloadIntentId: zod_1.z.string().uuid().transform(value => value.toLowerCase()),
}).strict();
exports.DatasetFileAccessMemberSchema = zod_1.z.object({ id, contentId: id, component: content_schema_1.DatasetMaterialComponentSchema,
    role: content_schema_1.DatasetMaterialRoleSchema, relativePath: zod_1.z.string().max(1_024).nullable(), groupId: id.nullable(),
    uploadObjectId: id, originalFileName: zod_1.z.string().max(1_024).nullable(), measuredSizeBytes: bytes,
    // Selected working files have not necessarily been submitted for review.
    membershipEvidenceId: id, inspection: files_schema_1.DatasetFilesInventoryMemberSchema.shape.inspection,
}).strict();
exports.DatasetFileAccessPageResponseSchema = zod_1.z.object({ context: exports.DatasetFileAccessContextSchema,
    total: zod_1.z.number().int().min(0).max(1_000), items: zod_1.z.array(exports.DatasetFileAccessMemberSchema).max(50),
    nextCursor: exports.DatasetFileAccessPageQuerySchema.nullable(),
}).strict().refine(value => value.items.every(item => item.contentId === value.context.contentId && item.component === value.context.component), "File inventories cannot mix content or components");
exports.DatasetFileObservationQuerySchema = zod_1.z.object({ ...exact, memberId: id, evidenceId: id,
    afterId: id.optional(), limit: zod_1.z.coerce.number().int().min(1).max(20).default(10) }).strict();
exports.DatasetFileObservationSchema = zod_1.z.object({ id, evidenceId: id, profileId: zod_1.z.string().min(1).max(128),
    result: zod_1.z.enum(["COMPLETE", "STRUCTURE_ONLY", "UNSUPPORTED", "NOT_CHECKED", "FAILED"]),
    source: zod_1.z.discriminatedUnion("kind", [
        zod_1.z.object({ kind: zod_1.z.literal("PHYSICAL_OBJECT"), uploadObjectId: id }).strict(),
        zod_1.z.object({ kind: zod_1.z.literal("LOGICAL_ENTRY"), uploadObjectId: id, inventoryId: id, logicalEntryId: id, locator: content_schema_1.DatasetLogicalLocatorSchema }).strict(),
    ]), measuredSizeBytes: bytes, checksumSha256: zod_1.z.string().regex(/^[a-f0-9]{64}$/),
    origin: zod_1.z.literal("BACKEND_OBSERVED"),
    scope: zod_1.z.enum(["EXACT_UPLOADED_OBJECT", "EXACT_ARCHIVE_ENTRY"]),
    // Format observations only. Malware configuration and worker diagnostics are
    // private; observed shape/codec does not infer the supplier's domain or use.
    facts: zod_1.z.record(zod_1.z.string().max(64), zod_1.z.union([zod_1.z.string().max(512), zod_1.z.number().finite(), zod_1.z.boolean(), zod_1.z.null()]))
        .refine(value => Object.keys(value).length <= 128),
}).strict();
exports.DatasetFileObservationResponseSchema = zod_1.z.object({ context: exports.DatasetFileAccessContextSchema, memberId: id,
    evidenceId: id, evidenceRelationship: zod_1.z.enum(["CURRENT", "CAPTURED_FOR_MEMBERSHIP", "CURRENT_AND_CAPTURED"]),
    total: zod_1.z.number().int().min(0).max(16_384), items: zod_1.z.array(exports.DatasetFileObservationSchema).max(20),
    nextCursor: exports.DatasetFileObservationQuerySchema.nullable(),
}).strict();
exports.DatasetFileDownloadResponseSchema = zod_1.z.object({ context: exports.DatasetFileAccessContextSchema, memberId: id,
    downloadIntentId: zod_1.z.string().uuid(), fileName: zod_1.z.string().min(1).max(255), measuredSizeBytes: bytes,
    url: zod_1.z.url().max(4_096).refine(value => new URL(value).protocol === "https:", "A private HTTPS download URL is required"),
    expiresAt: zod_1.z.string().datetime(), expiresInSeconds: zod_1.z.literal(60), disposition: zod_1.z.literal("ATTACHMENT"),
}).strict();
exports.DatasetFileBundleQuerySchema = exports.DatasetFileAccessPageQuerySchema.omit({ afterId: true, limit: true }).extend({
    downloadIntentId: zod_1.z.string().uuid().transform(value => value.toLowerCase()),
}).strict().refine(value => value.scope === "PUBLISHED" && value.component === "SAMPLE" ||
    value.scope === "GRANTED" && value.component === "FULL", "Choose the published sample or granted full material");
exports.DatasetFileBundleManifestSchema = zod_1.z.object({ context: exports.DatasetFileAccessContextSchema,
    downloadIntentId: zod_1.z.string().uuid(), fileName: zod_1.z.string().max(200), totalBytes: bytes,
    files: zod_1.z.array(zod_1.z.object({ memberId: id, path: zod_1.z.string().min(1).max(1_100), sizeBytes: bytes }).strict()).min(1).max(1_000),
}).strict();
