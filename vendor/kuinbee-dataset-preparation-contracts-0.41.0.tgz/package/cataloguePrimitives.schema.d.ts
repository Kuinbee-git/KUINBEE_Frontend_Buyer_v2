import { z } from "zod";
export declare const IsoDateTimeStringSchema: z.ZodString;
export declare const PaginationQuerySchema: z.ZodObject<{
    page: z.ZodOptional<z.ZodDefault<z.ZodCoercedNumber<unknown>>>;
    pageSize: z.ZodOptional<z.ZodDefault<z.ZodCoercedNumber<unknown>>>;
}, z.core.$strip>;
export declare const PaginatedResponseSchema: <T extends z.ZodTypeAny>(itemSchema: T) => z.ZodObject<{
    items: z.ZodArray<T>;
    page: z.ZodNumber;
    pageSize: z.ZodNumber;
    total: z.ZodNumber;
}, z.core.$strip>;
export type PaginatedResponse<T> = {
    items: T[];
    page: number;
    pageSize: number;
    total: number;
};
export declare const DecimalStringSchema: z.ZodString;
export declare const BigIntStringSchema: z.ZodString;
export declare const EncodingSchema: z.ZodEnum<{
    "UTF-8": "UTF-8";
    "UTF-16": "UTF-16";
    "UTF-16LE": "UTF-16LE";
    "UTF-16BE": "UTF-16BE";
    "UTF-32": "UTF-32";
    ASCII: "ASCII";
    "ISO-8859-1": "ISO-8859-1";
    "WINDOWS-1252": "WINDOWS-1252";
    SHIFT_JIS: "SHIFT_JIS";
    GB18030: "GB18030";
}>;
export declare const DatasetVisibilitySchema: z.ZodEnum<{
    PUBLIC: "PUBLIC";
    PRIVATE: "PRIVATE";
    UNLISTED: "UNLISTED";
}>;
export declare const CurrencySchema: z.ZodEnum<{
    INR: "INR";
    USD: "USD";
    EUR: "EUR";
    GBP: "GBP";
}>;
export declare const DatasetDiscountTargetSurfaceSchema: z.ZodEnum<{
    DATASET_PRICING: "DATASET_PRICING";
    SAMPLE_ACTUAL_PRICE: "SAMPLE_ACTUAL_PRICE";
}>;
export declare const DatasetDiscountTypeSchema: z.ZodEnum<{
    PERCENTAGE: "PERCENTAGE";
    FIXED_AMOUNT: "FIXED_AMOUNT";
}>;
export declare const CuidSchema: z.ZodString;
//# sourceMappingURL=cataloguePrimitives.schema.d.ts.map