import { z } from "zod";
export declare const DatasetCorrectionContextSchema: z.ZodEnum<{
    REQUESTED_CHANGES: "REQUESTED_CHANGES";
    MANAGED_EDIT: "MANAGED_EDIT";
    APPROVED_REEDIT: "APPROVED_REEDIT";
    PLATFORM_WITHDRAWAL: "PLATFORM_WITHDRAWAL";
    PLATFORM_PUBLISHED_METADATA: "PLATFORM_PUBLISHED_METADATA";
}>;
export declare const DatasetCorrectionPreconditionSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    mode: z.ZodLiteral<"EXISTING_DRAFT">;
    expectedContentId: z.ZodString;
    expectedGeneration: z.ZodNumber;
}, z.core.$strict>, z.ZodObject<{
    mode: z.ZodLiteral<"INITIALIZE">;
    expectedWorkflowRevision: z.ZodNumber;
    context: z.ZodEnum<{
        REQUESTED_CHANGES: "REQUESTED_CHANGES";
        MANAGED_EDIT: "MANAGED_EDIT";
        APPROVED_REEDIT: "APPROVED_REEDIT";
        PLATFORM_WITHDRAWAL: "PLATFORM_WITHDRAWAL";
        PLATFORM_PUBLISHED_METADATA: "PLATFORM_PUBLISHED_METADATA";
    }>;
    expectedBaseContentId: z.ZodString;
}, z.core.$strict>], "mode">;
export declare const DatasetEditOperationSchema: z.ZodEnum<{
    METADATA: "METADATA";
    PRICING: "PRICING";
    MATERIALS: "MATERIALS";
}>;
export declare const DatasetEditContextQuerySchema: z.ZodObject<{
    operation: z.ZodEnum<{
        METADATA: "METADATA";
        PRICING: "PRICING";
        MATERIALS: "MATERIALS";
    }>;
}, z.core.$strict>;
export declare const DatasetEditContextResponseSchema: z.ZodObject<{
    datasetId: z.ZodString;
    operation: z.ZodEnum<{
        METADATA: "METADATA";
        PRICING: "PRICING";
        MATERIALS: "MATERIALS";
    }>;
    preparationGeneration: z.ZodNumber;
    workflowRevision: z.ZodNumber;
    managementContext: z.ZodEnum<{
        INITIAL_PROPOSAL: "INITIAL_PROPOSAL";
        MANAGED: "MANAGED";
    }>;
    editable: z.ZodBoolean;
    precondition: z.ZodNullable<z.ZodDiscriminatedUnion<[z.ZodObject<{
        mode: z.ZodLiteral<"EXISTING_DRAFT">;
        expectedContentId: z.ZodString;
        expectedGeneration: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        mode: z.ZodLiteral<"INITIALIZE">;
        expectedWorkflowRevision: z.ZodNumber;
        context: z.ZodEnum<{
            REQUESTED_CHANGES: "REQUESTED_CHANGES";
            MANAGED_EDIT: "MANAGED_EDIT";
            APPROVED_REEDIT: "APPROVED_REEDIT";
            PLATFORM_WITHDRAWAL: "PLATFORM_WITHDRAWAL";
            PLATFORM_PUBLISHED_METADATA: "PLATFORM_PUBLISHED_METADATA";
        }>;
        expectedBaseContentId: z.ZodString;
    }, z.core.$strict>], "mode">>;
    reason: z.ZodNullable<z.ZodString>;
}, z.core.$strict>;
export type DatasetCorrectionContext = z.infer<typeof DatasetCorrectionContextSchema>;
export type DatasetCorrectionPrecondition = z.infer<typeof DatasetCorrectionPreconditionSchema>;
//# sourceMappingURL=edit.schema.d.ts.map