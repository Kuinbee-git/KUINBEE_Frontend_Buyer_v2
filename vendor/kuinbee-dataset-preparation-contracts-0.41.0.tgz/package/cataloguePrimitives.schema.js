"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CuidSchema = exports.DatasetDiscountTypeSchema = exports.DatasetDiscountTargetSurfaceSchema = exports.CurrencySchema = exports.DatasetVisibilitySchema = exports.EncodingSchema = exports.BigIntStringSchema = exports.DecimalStringSchema = exports.PaginatedResponseSchema = exports.PaginationQuerySchema = exports.IsoDateTimeStringSchema = void 0;
const zod_1 = require("zod");
// Shared wire primitives; no admin/user records or service dependencies.
exports.IsoDateTimeStringSchema = zod_1.z.string().datetime();
exports.PaginationQuerySchema = zod_1.z.object({
    page: zod_1.z.coerce.number().int().min(1).default(1),
    pageSize: zod_1.z.coerce.number().int().min(1).max(200).default(20),
}).partial();
const PaginatedResponseSchema = (itemSchema) => zod_1.z.object({
    items: zod_1.z.array(itemSchema),
    page: zod_1.z.number().int().min(1),
    pageSize: zod_1.z.number().int().min(1),
    total: zod_1.z.number().int().min(0),
});
exports.PaginatedResponseSchema = PaginatedResponseSchema;
exports.DecimalStringSchema = zod_1.z
    .string()
    .max(100)
    .regex(/^-?\d+(?:\.\d+)?$/, "Invalid decimal string");
exports.BigIntStringSchema = zod_1.z
    .string()
    .max(100)
    .regex(/^\d+$/, "Invalid bigint string");
exports.EncodingSchema = zod_1.z.enum([
    "UTF-8",
    "UTF-16",
    "UTF-16LE",
    "UTF-16BE",
    "UTF-32",
    "ASCII",
    "ISO-8859-1",
    "WINDOWS-1252",
    "SHIFT_JIS",
    "GB18030",
]);
exports.DatasetVisibilitySchema = zod_1.z.enum([
    "PUBLIC",
    "PRIVATE",
    "UNLISTED",
]);
exports.CurrencySchema = zod_1.z.enum(["INR", "USD", "EUR", "GBP"]);
exports.DatasetDiscountTargetSurfaceSchema = zod_1.z.enum([
    "DATASET_PRICING",
    "SAMPLE_ACTUAL_PRICE",
]);
exports.DatasetDiscountTypeSchema = zod_1.z.enum(["PERCENTAGE", "FIXED_AMOUNT"]);
exports.CuidSchema = zod_1.z.string().min(1).max(128);
