import { z } from "zod";
export declare const datasetCategoryLegacySlug: (name: string) => string;
export declare const datasetCategoryRouteKey: (categoryId: string, name: string) => string;
export declare const DatasetPublicCategorySchema: z.ZodObject<{
    id: z.ZodString;
    name: z.ZodString;
    routeKey: z.ZodString;
    datasetCount: z.ZodNumber;
}, z.core.$strict>;
export declare const DatasetCategoryDirectoryQuerySchema: z.ZodObject<{
    q: z.ZodOptional<z.ZodString>;
    expectedRevision: z.ZodOptional<z.ZodString>;
    afterId: z.ZodOptional<z.ZodString>;
    limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
}, z.core.$strict>;
export declare const DatasetCategoryDirectoryResponseSchema: z.ZodObject<{
    revision: z.ZodString;
    total: z.ZodNumber;
    items: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
        routeKey: z.ZodString;
        datasetCount: z.ZodNumber;
    }, z.core.$strict>>;
    nextCursor: z.ZodNullable<z.ZodObject<{
        q: z.ZodOptional<z.ZodString>;
        expectedRevision: z.ZodOptional<z.ZodString>;
        afterId: z.ZodOptional<z.ZodString>;
        limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const DatasetCategoryResolveParamsSchema: z.ZodObject<{
    key: z.ZodString;
}, z.core.$strict>;
export declare const DatasetCategoryResolveResponseSchema: z.ZodObject<{
    revision: z.ZodString;
    requestedKey: z.ZodString;
    category: z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
        routeKey: z.ZodString;
        datasetCount: z.ZodNumber;
    }, z.core.$strict>;
    redirect: z.ZodBoolean;
}, z.core.$strict>;
export type DatasetPublicCategory = z.infer<typeof DatasetPublicCategorySchema>;
export type DatasetCategoryDirectoryQuery = z.infer<typeof DatasetCategoryDirectoryQuerySchema>;
export type DatasetCategoryDirectoryResponse = z.infer<typeof DatasetCategoryDirectoryResponseSchema>;
export type DatasetCategoryResolveResponse = z.infer<typeof DatasetCategoryResolveResponseSchema>;
//# sourceMappingURL=category.schema.d.ts.map